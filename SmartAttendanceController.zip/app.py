
from flask import Flask, render_template, Response
import face_recognition
import cv2
import numpy as np
import csv
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

# Load known faces and their names
known_face_encodings = []
known_face_names = []

# Load a sample picture and learn how to recognize it.
image = face_recognition.load_image_file("known_face.jpg")
known_face_encodings.append(face_recognition.face_encodings(image)[0])
known_face_names.append("Student Name")

# Initialize some variables
face_locations = []
face_encodings = []
face_names = []

video_capture = cv2.VideoCapture(0)  # Use 0 for the webcam

attendance_file = 'attendance.csv'

def mark_attendance(name):
    with open(attendance_file, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, datetime.now()])
    send_email(name)

def send_email(student_name):
    email_user = 'youremail@example.com'
    email_password = 'yourpassword'
    email_send = 'recipient@example.com'

    subject = 'Attendance Notification'

    msg = MIMEMultipart()
    msg['From'] = email_user
    msg['To'] = email_send
    msg['Subject'] = subject

    body = f'{student_name} has attended the class.'
    msg.attach(MIMEText(body, 'plain'))

    text = msg.as_string()
    server = smtplib.SMTP('smtp.example.com', 587)
    server.starttls()
    server.login(email_user, email_password)

    server.sendmail(email_user, email_send, text)
    server.quit()

@app.route('/')
def index():
    return render_template('index.html')

def gen():
    while True:
        ret, frame = video_capture.read()
        rgb_frame = frame[:, :, ::-1]

        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        face_names = []
        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"

            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]

            face_names.append(name)

            if name != "Unknown":
                mark_attendance(name)

        for (top, right, bottom, left), name in zip(face_locations, face_names):
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 0.5, (0, 0, 255), 1)

        ret, jpeg = cv2.imencode('.jpg', frame)
        frame = jpeg.tobytes()
        yield (b'--frame
'
               b'Content-Type: image/jpeg

' + frame + b'

')

@app.route('/video_feed')
def video_feed():
    return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)
    